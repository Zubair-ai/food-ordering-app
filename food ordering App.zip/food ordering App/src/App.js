import React from "react";
import FirstPage from "./pages/firstPage";



function App() {
  
  return (
    <div>
      {<FirstPage/>}
    </div>
  );
}

export default App;
